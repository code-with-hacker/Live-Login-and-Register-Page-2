<?php

session_start();

if(isset($_GET['email']) && isset($_GET['password']) && !isset($_SESSION['user_email'])){

    include("db.php");

    $email = mysqli_real_escape_string($con, $_GET['email']);

    $password = mysqli_real_escape_string($con, $_GET['password']);

    $sel_user = "SELECT * FROM account WHERE email='$email' LIMIT 0,1";

    $run_user = mysqli_query($con, $sel_user);

    $count_user = mysqli_num_rows($run_user);

    if($count_user>0){

        $row_user = mysqli_fetch_array($run_user);

        $password_hash = mysqli_real_escape_string($con, $row_user['password']);

        if(password_verify($password, $password_hash)){

            echo "<span class='icon-2'>You are Logged In!</span>";

            $_SESSION['user_email'] = $email;

        }else{

            echo "<span class='icon-2'>Invalid User Details!</span>";

        }

    }else{

        echo "<span class='icon-2'>Invalid User Details!</span>";

    }

}else{

    echo "<span class='icon-2'>Bad Request!</span>";

}

?>