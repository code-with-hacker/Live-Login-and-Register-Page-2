$(function() {
    jQuery(document).ready(function() {
        $("body").backstretch([
            "img/background-1.jpg",
            "img/background-2.jpg",
            "img/background-3.jpg",
        ], {duration: 3200, fade: 1300});
    });
});

$(function() {
    $("#login-form-link").click(function(e) {
        $("#login-form").delay(100).fadeIn(100);
        $("#register-form").fadeOut(100);
        $("#register-form-link").removeClass("active");
        $(this).addClass("active");
        e.preventDefault();
    });

    $("#register-form-link").click(function(e) {
        $("#register-form").delay(100).fadeIn(100);
        $("#login-form").fadeOut(100);
        $("#login-form-link").removeClass("active");
        $(this).addClass("active");
        e.preventDefault();
    });
});

// For the Form Not to be Submitted

form_login = document.getElementById("login-form");
form_register = document.getElementById("register-form");

form_login.addEventListener("submit", notsubmit);
form_register.addEventListener("submit", notsubmit);

function notsubmit(e){
    e.preventDefault();
}

// Register Form Function

function register(){
    username = document.getElementById("username");
    email = document.getElementById("email-register");
    password = document.getElementById("password-register");
    submit_register = document.getElementById("submit-register");
    output_register = document.getElementById("output-register");
    submit_register.style.display = "none";
    output_register.style.display = "block";
    output_register.innerHTML = `<span class='icon-2'><i class='fa fa-spinner fa-pulse fa-2x'></i></span>`;
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "register.php?username="+username.value+"&email="+email.value+"&password="+password.value, true);
    xhr.onload = function(){
        if(xhr.status==200){
            username.value = null;
            email.value = null;
            password.value = null;
            output_register.innerHTML = '';
            output_register.innerHTML = xhr.responseText;
        }else{
            username.value = null;
            email.value = null;
            password.value = null;
            output_register.innerHTML = '';
            output_register.innerHTML = `<span class='icon-2'>Something Went Wrong!</span>`;
        }
    }

    xhr.send();
}


// Login Form Function

function login(){
    email = document.getElementById("email");
    password = document.getElementById("password");
    submit_login = document.getElementById("submit-login");
    output_login = document.getElementById("output-login");
    submit_login.style.display = "none";
    output_login.style.display = "block";
    output_login.innerHTML = `<span class='icon-2'><i class='fa fa-spinner fa-pulse fa-2x'></i></span>`;
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "login.php?email="+email.value+"&password="+password.value, true);
    xhr.onload = function(){
        if(xhr.status==200){
            email.value = null;
            password.value = null;
            output_login.innerHTML = '';
            output_login.innerHTML = xhr.responseText;
            window.open("index.php", "_self");
        }else{
            email.value = null;
            password.value = null;
            output_login.innerHTML = '';
            output_login.innerHTML =   `<span class='icon-2'>Something Went Wrong!</span>`;
        }
    }

    xhr.send();
}
