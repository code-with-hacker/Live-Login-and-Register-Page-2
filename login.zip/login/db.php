<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "users";

$con = mysqli_connect($host, $username, $password, $database);

if($con){
    return true;
}else{
    return mysqli_error($con);
    return false;
}

?>