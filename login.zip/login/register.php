<?php

session_start();

if(isset($_GET['username']) && isset($_GET['email']) && isset($_GET['password']) && !isset($_SESSION['user_email'])){

    include("db.php");

    $username = mysqli_real_escape_string($con, $_GET['username']);

    $email = mysqli_real_escape_string($con, $_GET['email']);

    $password = mysqli_real_escape_string($con, $_GET['password']);

    $sel_user = "SELECT * FROM account WHERE email='$email'";

    $run_user = mysqli_query($con, $sel_user);

    $count_user = mysqli_num_rows($run_user);

    if($count_user==0){

        $password_hash = password_hash($password, PASSWORD_BCRYPT);

        $insert_user = "INSERT INTO account (username,email,password) VALUES ('$username','$email','$password_hash')";

        $run_insert_user = mysqli_query($con, $insert_user);

        if($run_insert_user){

            echo "<span class='icon-2'>User Registered Successfully!</span>";

        }else{

            echo "<span class='icon-2'>" . mysqli_error($con) . "</span>";

        }

    }else{

        echo "<span class='icon-2'>A User with this E-mail Already Exists!</span>";

    }

}else{

    echo "<span class='icon-2'>Bad Request</span>";

}

?>