<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Login and Register Page</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="h2 text-center">Login and Register Page</h2>
                    </div>
                    <div class="card-body">
                        <a href="#" class="card-link active" id="login-form-link" style="margin-left: 200px; margin-right: 300px;">Login</a>
                        <a href="#" class="card-link" id="register-form-link">Register</a>
                        <hr />
                        <div class="main-body">
                            <?php
                            
                            session_start();

                            if(!isset($_SESSION['user_email'])){
                            
                            ?>
                            <form action="" method="get" class="form form-horizontal" id="login-form" enctype="multipart/form-data" onsubmit="login()" style="display: block;">
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Type Your E-mail" value="" id="email" class="form-control" required /><span class="icon-1"><i class="fa fa-envelope-o"></i></span>
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" id="password" placeholder="Type your Password" value="" class="form-control" required /><span class="icon-1"><i class="fa fa-key"></i></span>
                                </div>
                                <div class="form-group">
                                    <a href="#" class="forgot-password" id="forgot-password">Forgot Password?</a>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-outline-primary btn-login" id="submit-login" name="submit-login" value="Log In">Log In</button>
                                    <div id="output-login" style="display: none;">

                                    </div>
                                </div>
                            </form>
                            <form action="" method="get" class="form form-horizontal" id="register-form" onsubmit="register()" style="display: none;">
                                <div class="form-group">
                                    <input type="text" name="username" placeholder="Type Your Username" value="" id="username" class="form-control" required /><span class="icon-1"><i class="fa fa-user-o"></i></span>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email-register" id="email-register" placeholder="Type Your E-mail" value="" class="form-control" required /><span class="icon-1"><i class="fa fa-envelope-o"></i></span>
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password-register" id="password-register" placeholder="Type Your Password" value="" class="form-control" required /><span class="icon-1"><i class="fa fa-key"></i></span>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-outline-success btn-register" id="submit-register" name="submit-register" value="Register Now">Register Now</button>
                                    <div id="output-register" style="display: none;">

                                    </div>
                                </div>
                            </form>
                            <?php
                            
                            }else{

                                include("db.php");

                                $email = mysqli_real_escape_string($con, $_SESSION['user_email']);

                                $sel_user = "SELECT * FROM account WHERE email='$email' LIMIT 0,1";

                                $run_user = mysqli_query($con, $sel_user);

                                $row_user = mysqli_fetch_array($run_user);

                                $username = mysqli_real_escape_string($con, $row_user['username']);

                            ?>
                                
                                <h1 class="text-center">Hello <span style="color: #0056b3;"><?php echo $username; ?></span></h1>
                                <p class="text-center" style="color: green;">You are Logged In!</p>
                                <p class="text-center"><a href="logout.php">Logout</a></p>

                            <?php

                            }
                            
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/jquery.backstretch.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>